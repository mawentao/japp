/* index.js, (c) 2016 mawentao */
define(function(require){
    var o = {};

    o.indexAction = function() {
        window.location = "#/japp";
    };

    return o;
});
