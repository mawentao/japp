/* conf.js, (c) 2016 mawentao */
define(function(require){
return {
    pluginId: 'hello',
    pluginName: 'Hello',
    icon: '<i class="fa fa-qq"></i>',
    menu: [
        {name:'HelloWorld',path:'#/hello'}
    ]
};
});
