/* framework.js, (c) 2016 mawentao */
define(function(require){
    return require("./default/frame");
});
